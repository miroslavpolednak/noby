# run_pytest.ps1
Invoke-Expression -Command "pytest .\automat_health.py"
