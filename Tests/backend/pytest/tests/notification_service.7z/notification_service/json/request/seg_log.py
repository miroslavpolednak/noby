json_req_basic_log = \
    {"Title": "New Signal",
     "Description": None,
     "Filters": [],
     "Columns": [],
     "IsWatched": False,
     "Id": None,
     "Grouping": "Inferred",
     "ExplicitGroupName": None,
     "OwnerId": "user-admin",
     "Links": {"Create": "api/signals/"}}
